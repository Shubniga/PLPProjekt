package login;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import login.LoginLinkClass;

public class VerifyLoginLinkClass {
	
	static WebDriver driver;
	List<String> email = new ArrayList<String>();
	List<String> pwd = new ArrayList<String>();
	LoginLinkClass LoginLinkClassObject;
	
	@BeforeClass
	public void beforeClass() throws InterruptedException
	{	
		//1.	Launching the application browser, Chrome
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();

		//2.	Open the web page �Registration Form.html � in the browser.
		driver.get("http://www.phptravels.net/Login/");
		LoginLinkClassObject = PageFactory.initElements(driver, LoginLinkClass.class);
		Thread.sleep(2000);
		
		// Creating a list  
		email.add("ajayRaaj789@gmail.com");  // adds 1 at 0 index 
		email.add("nirajBhai456@gmail.com");  // adds 2 at 1 index 
		System.out.println(email);  // [1, 2] 

		// Creating another list  
		pwd.add("789@Ajay"); 
		pwd.add("456$Niraj"); 
		//pwd.add(3); 
		System.out.println(pwd);
	}

	//3.	Verify the title �Login� of the page. 
	//The test should stop execution if the title of the page is not matching with the expected title.
	@Test(priority=1)
	public void verifyTitle()
	{	
		String expectedTitle="Login";
		LoginLinkClassObject.verifyTitle(expectedTitle);
	}
	
	@Test(priority=2)
	public void verifyLoginHeading()
	{	
		String expectedTitle="LOGIN";
		LoginLinkClassObject.verifyLoginHeading(expectedTitle);
	}
	
	@Test(priority=3)
	public void verifyEmailLabel()
	{	
		String expectedTitle="Email";
		LoginLinkClassObject.verifyEmailLabel(expectedTitle);
	}

	@Test(priority=4)
	public void verifyPasswordLabel()
	{	
		String expectedTitle="Password";
		LoginLinkClassObject.verifyPasswordLabel(expectedTitle);
	}
	
	@Test(priority=5)
	public void verifyRemembermeLabel()
	{	
		String expectedTitle="  Remember Me  ";
		LoginLinkClassObject.verifyRemembermeLabel(expectedTitle);
	}
	
	@Test(priority=6)
	public void verifyLoginButtonText() throws InterruptedException
	{	Thread.sleep(1000);
		String expectedTitle="LOGIN";
		LoginLinkClassObject.verifyLoginButtonText(expectedTitle);
	}
	
	@Test(priority=7)
	public void verifySignUpButtonText()
	{	
		String expectedTitle="SIGN UP";
		LoginLinkClassObject.verifySignUpButtonText(expectedTitle);
	}
	
	@Test(priority=8)
	public void verifyForgetPasswordText()
	{	
		String expectedTitle="FORGET PASSWORD";
		LoginLinkClassObject.verifyForgotPasswordText(expectedTitle);
	}
}
