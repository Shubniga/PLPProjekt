package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import login.LoginLinkClass;

public class LoginLink
{
	LoginLinkClass loginclass;
	WebDriver driver;
	By loginbuttonclick = By.xpath("//*[@id='loginfrm']/button");
	By emailinput = By.xpath("//input[@name='username']");
	By passwordinput = By.xpath("//*[@id='loginfrm']/div[1]/div[5]/div/div[2]/input");
	By signupbuttonclick = By.xpath("//*[@id='loginfrm']/div[2]/div[1]/a");
	By alertmessage = By.xpath("//*[@id='loginfrm']/div[1]/div[2]/div");
	By forgetbuttonclick = By.xpath("//*[@id='loginfrm']/div[2]/div[3]/a");
	String actual;
	public LoginLink(WebDriver driver)
	{
		this.driver =driver;
	}
	
	//To validate the email input of login page
	public void emailinput() throws InterruptedException
	{
		Thread.sleep(1000);
		driver.findElement(emailinput).sendKeys("ajayRaaj789@gmail.com");
		System.out.println("email input located");
	}
	
	//To validate the passord input of login page
	public void passwordinput() throws InterruptedException
	{
		driver.findElement(passwordinput).sendKeys("ajay@789");
		System.out.println("password input located");
		Thread.sleep(1000);
	}
	
	//To validate the login button of login page
	public void loginbuttonclick() throws InterruptedException
	{
		driver.findElement(loginbuttonclick).click();
		System.out.println("login button located");
		Thread.sleep(1000);
	}
	
	//To validate the signup button of login page
	public void signupbuttonclick() throws InterruptedException
	{
		driver.findElement(signupbuttonclick).click();
		System.out.println("sign up button located");
		Thread.sleep(1000);
	}
	
	//To validate the signup button of login page
		public void forgetbuttonclick() throws InterruptedException
		{
			driver.findElement(forgetbuttonclick).click();
			System.out.println("sign up button located");
			Thread.sleep(1000);
		}
	
	//To validate the error message is displayed
	public void alertmessage()
	{
		actual = driver.findElement(alertmessage).getText();
		loginclass.verifyalertmessage(actual);
		System.out.println("Alert message located");
	}
	
//	public static void main(String[] args) throws InterruptedException
//	{
//		System.setProperty("webdriver.chrome.driver","D:/chromedriver.exe");
//		WebDriver driver = new ChromeDriver();
//
//		driver.get("http://www.phptravels.net/Login/");
//		
//		LoginLink lk=new LoginLink(driver);
//		lk.emailinput();
//		lk.passwordinput();
//		lk.loginbuttonclick(); 
//		lk.alertmessage();
//		lk.signupbuttonclick();
//		lk.forgetbuttonclick();
//	}
}

