
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class asdf 
{
  static WebDriver driver;
  public asdf(WebDriver driver)
  {
	  this.driver=driver;
	  PageFactory.initElements(driver,this);
  }
  
  @FindBy(how=How.XPATH, using="//*[@id='hero']/div/div/div/div/div[1]")
  @CacheLookup
  WebElement SignUpText;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[3]/label")
  @CacheLookup
  WebElement firstNameLabel;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[3]/input")
  @CacheLookup
  WebElement firstName;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[4]/label")
  @CacheLookup
  WebElement lastNameLabel;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[4]/input")
  @CacheLookup
  WebElement lastName;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[5]/label")
  @CacheLookup
  WebElement mobileLable;
  
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[5]/input")
  @CacheLookup
  WebElement mobileNumber;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[6]/label")
  @CacheLookup
  WebElement emailLable;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[6]/input")
  @CacheLookup
  WebElement email;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[7]/label")
  @CacheLookup
  WebElement passwordLabel;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[7]/input")
  @CacheLookup
  WebElement password;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[8]/label")
  @CacheLookup
  WebElement confirmpasswordLabel;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[8]/input")
  @CacheLookup
  WebElement confirmPassword;
  
  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[9]/button")
  @CacheLookup
  WebElement submitButton;
  
  
  @FindBy(xpath="//*[@id='headersignupform']/div[2]/div")
  @CacheLookup
  WebElement firstNameFieldMessage;
  
  
  
  
  public void enterFirstName(String str)
  {
	  firstName.sendKeys(str);
  }
  
  public void enterLastName(String str)
  {
	  lastName.sendKeys(str);
  }
  
  public void enterMobileNumber(String str)
  {
	 mobileNumber.sendKeys(str);
  }
  
  public void enterEmail(String str)
  {
	 email.sendKeys(str);
  }
  
  
  public void enterPassword(String str)
  {
	 password.sendKeys(str);
  }
  
  public void enterConfirmPassword(String str)
  {
	 confirmPassword.sendKeys(str);
  }
  
  public void submitSignUp()
  {
	  submitButton.click();
  }
  
  public void verifyAfterSignUpPage()
  {
	
	 String expURL="http://www.phptravels.net/account/";
	 String actURL=driver.getCurrentUrl();
	 if(expURL.contentEquals(actURL))
	 {
		 
		 System.out.println("Redirecting to Account Page After Sign Up Test Case -Passed");
	 }
	 else
	 {
		 System.out.println("Redirecting to Account Page After Sign Up Test Case -Failed");

	 }
  }

  
	public void verifyFirstNameLabel()
	{
		if(stringEquals(firstNameLabel,"First Name"))
		{
			System.out.println("First Name Label Text--Test Passed");
		}
		else
		{
			System.out.println("First Name Label Text--Test Failed");
		}
	}
	
	public void verifyLastNameLabel()
	{
		if(stringEquals(lastNameLabel,"Last Name"))
		{
			System.out.println("Last Name Label Text--Test Passed");
		}
		else
		{
			System.out.println("Last Name Label Text--Test Failed");
		}
	}
	
	public void verifymobileLabel()
	{
		if(stringEquals(mobileLable,"Mobile Number"))
		{
			System.out.println("Mobile Label Text--Test Passed");
		}
		else
		{
			System.out.println("Mobile Label Text--Test Failed");
		}
	}

	public void verifySignUpText()
	{
		if(stringEquals(SignUpText,"SIGN UP"))
		{
			System.out.println("SIGN UP Present--Test Passed");
		}
		else
		{
			System.out.println("Mobile Label Present--Test Failed");
		}
	}

	public void verifyEmailLabel()
	{
		if(stringEquals(emailLable,"Email"))
		{
			System.out.println("Email Label Text--Test Passed");
		}
		else
		{
			System.out.println("Email Label Text--Test Failed");
		}
	}

	
	public void verifyPasswordLabel()
	{
		if(stringEquals(passwordLabel,"Password"))
		{
			System.out.println("Password Label Text--Test Passed");
		}
		else
		{
			System.out.println("Password Label Text--Test Failed");
		}
	}
  
	public void verifyConfirmPasswordLabel()
	{
		if(stringEquals(confirmpasswordLabel,"Confirm Password"))
		{
			System.out.println("Confirm Password Label Text--Test Passed");
		}
		else
		{
			System.out.println("Confirm Password Label Text--Test Failed");
		}
	}

	public void verifySignUpButtonText()
	{
		if(stringEquals(submitButton,"SIGN UP"))
		{
			System.out.println("SIGN UP Button Text Present--Test Passed");
		}
		else
		{
			System.out.println("SIGN UP Button Text--Test Failed");
		}
	}
  
  
	public boolean isFirstNameDisplayed()
	{
		if(firstName.isDisplayed()&& firstName.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isLastNameDisplayed()
	{
		if(lastName.isDisplayed()&& lastName.isEnabled())
		{
			return true;
		}
		else
			return false;
	}

	
	public boolean isMobileDisplayed()
	{
		if(mobileNumber.isDisplayed()&& mobileNumber.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	
	public boolean isEmailDisplayed()
	{
		if(email.isDisplayed()&& email.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isPasswordDisplayed()
	{
		if(password.isDisplayed()&& password.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean isConfirmPasswordDisplayed()
	{
		if(confirmPassword.isDisplayed()&& confirmPassword.isEnabled())
		{
			return true;
		}
		else
			return false;
	}

	
	public boolean isSignUpButtonDisplayed()
	{
		if(submitButton.isDisplayed()&& submitButton.isEnabled())
		{
			return true;
		}
		else
			return false;
	}
	
	
	
	public boolean stringEquals(WebElement element,String expData)
	{
	  String str=element.getText();
	  if(str.contentEquals(expData))
		 
	  {
		
		  return true;
	  }
	  else
	  {
		 
		  return false;
	  }
	}
  
	public void verifyFirstNameBlank()
	{
		if(isFirstNameDisplayed())
		{
			System.out.println("First Name field is Present");
			enterFirstName("");
			submitSignUp();
			if(firstNameFieldMessage.isDisplayed())
			{
				String actStr=firstNameFieldMessage.getText();
				String expSubStr="The First name field is required.";
				if(actStr.contains(expSubStr))
				{
					System.out.println("First Name left blank Test Passed");
				}
				else
				{
					System.out.println("First Name left blank Test Failed");
				}
			}
			else
			{
				System.out.println("First Name left blank Test Failed");

			}
		}
		System.out.println("First Name field is absent");
			
	}


	
}
