package SignupPagePF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class SignUpPageClass
{
	static WebDriver driver;
	  public SignUpPageClass(WebDriver driver)
	  {
		  this.driver=driver;
		  PageFactory.initElements(driver,this);
	  }
	  
	  @FindBy(how=How.XPATH, using="//*[@id='hero']/div/div/div/div/div[1]")
	  @CacheLookup
	  WebElement SignUpText;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[3]/label")
	  @CacheLookup
	  WebElement firstNameLabel;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[3]/input")
	  @CacheLookup
	  WebElement firstName;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[4]/label")
	  @CacheLookup
	  WebElement lastNameLabel;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[4]/input")
	  @CacheLookup
	  WebElement lastName;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[5]/label")
	  @CacheLookup
	  WebElement mobileLable;
	  
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[5]/input")
	  @CacheLookup
	  WebElement mobileNumber;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[6]/label")
	  @CacheLookup
	  WebElement emailLable;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[6]/input")
	  @CacheLookup
	  WebElement email;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[7]/label")
	  @CacheLookup
	  WebElement passwordLabel;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[7]/input")
	  @CacheLookup
	  WebElement password;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[7]/input")
	  @CacheLookup
	  WebElement confirmpasswordLabel;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[8]/input")
	  @CacheLookup
	  WebElement confirmPassword;
	  
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[9]/button")
	  @CacheLookup
	  WebElement submitButton;
	  
	  //Error Message line 1
	  @FindBy(how=How.XPATH, using="//*[@id='headersignupform']/div[2]/div/p[1]")
	  @CacheLookup
	  WebElement errormessageL1;
	  
	  
	  
	  
	  
	  public void enterFirstName(String str)
	  {
		  firstName.sendKeys(str);
	  }
	  
	  public void enterLastName(String str)
	  {
		  lastName.sendKeys(str);
	  }
	  
	  public void enterMobileNumber(String str)
	  {
		 mobileNumber.sendKeys(str);
	  }
	  
	  public void enterEmail(String str)
	  {
		 email.sendKeys(str);
	  }
	  
	  
	  public void enterPassword(String str)
	  {
		 password.sendKeys(str);
	  }
	  
	  public void enterConfirmPassword(String str)
	  {
		 confirmPassword.sendKeys(str);
	  }
	  
	  public void submitSignUp()
	  {
		  submitButton.click();
	  }
	  
	  //Verify whether error message is displayed when first name is left blank and submit button is clicked
	  public void isErrorMessageFNEmpty(String e1) throws InterruptedException
	  {
		  enterLastName("asdfgh");
		  enterMobileNumber("1234567892");
		  enterEmail("asd@asdf.asdfg");
		  enterPassword("asdfghjk");
		  enterConfirmPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(3000);
		  String act = errormessageL1.getText();
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on first name left bank - PASSED");
		  else
			  System.out.println("Error message displayed on first name left bank - FAILED");
	  }
	  
	  //Verify whether error message is displayed when only numbers are entered in first name and submit button is clicked
	/*  public void isErrorMessageFNNumbers(String e1) throws InterruptedException
	  {
		  resetElementValues();
		  enterFirstName("12345");
		  enterLastName("asdfgh");
		  enterMobileNumber("1234567892");
		  enterEmail("assd@asdf.asdfg");
		  enterPassword("asdfghjk");
		  enterConfirmPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(5000);
		  String act = errormessageL1.getText();
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on only numbers entered in First name - PASSED");
		  else
			  System.out.println("Error message displayed on only numbers entered in First name  - FAILED");
	  }*/
	  
	//Verify whether error message is displayed when last name is left blank and submit button is clicked
	  public void isErrorMessageLNEmpty(String e1) throws InterruptedException
	  {
		  resetElementValues();
		  enterFirstName("12345");
		  enterMobileNumber("1234567892");
		  enterEmail("sasd@asdf.asdfg");
		  enterPassword("asdfghjk");
		  enterConfirmPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(3000);
		  String act = errormessageL1.getText();
		  System.out.println(act);
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on last name left bank - PASSED");
		  else
			  System.out.println("Error message displayed on last name left bank - FAILED");
	  }
	  
	//Verify whether error message is displayed when mobile number is left blank and submit button is clicked
	  public void isErrorMessageMNEmpty(String e1) throws InterruptedException
	  {
		  resetElementValues();
		  enterFirstName("12345");
		  enterLastName("asdfgh");
		  enterEmail("asds@asdf.asdfg");
		  enterPassword("asdfghjk");
		  enterConfirmPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(3000);
		  String act = errormessageL1.getText();
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on mobile number left bank - PASSED");
		  else
			  System.out.println("Error message displayed on mobile number left bank - FAILED");
	  }
	  
	//Verify whether error message is displayed when email is left blank and submit button is clicked
	  public void isErrorMessageEmailEmpty(String e1) throws InterruptedException
	  {
		  resetElementValues();
		  enterFirstName("12345");
		  enterLastName("asdfgh");
		  enterMobileNumber("1234567892");
		  enterPassword("asdfghjk");
		  enterConfirmPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(3000);
		  String act = errormessageL1.getText();
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on email left bank - PASSED");
		  else
			  System.out.println("Error message displayed on email left bank - FAILED");
	  }
	  
	//Verify whether error message is displayed when password is left blank and submit button is clicked
	  public void isErrorMessagePasswordEmpty(String e1) throws InterruptedException
	  {
		  resetElementValues();
		  enterFirstName("12345");
		  enterLastName("asdfgh");
		  enterMobileNumber("1234567892");
		  enterEmail("asdss@asdf.asdfg");
		  enterConfirmPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(3000);
		  String act = errormessageL1.getText();
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on password left bank - PASSED");
		  else
			  System.out.println("Error message displayed on password left bank - FAILED");
	  }
	  
	//Verify whether error message is displayed when confirm password is left blank and submit button is clicked
	  public void isErrorMessageConfirmPasswordEmpty(String e1) throws InterruptedException
	  {
		  resetElementValues();
		  enterFirstName("12345");
		  enterLastName("asdfgh");
		  enterMobileNumber("1234567892");
		  enterEmail("sssasd@asdf.asdfg");
		  enterPassword("asdfghjk");
		  submitSignUp();
		  Thread.sleep(3000);
		  String act = errormessageL1.getText();
		  if(e1.contentEquals(act))
			  System.out.println("Error message displayed on confirm password left bank - PASSED");
		  else
			  System.out.println("Error message displayed on confirm password left bank - FAILED");
	  }
	  
	  //To clear the data in all the text fields
	  public void resetElementValues()
	  {
		  firstName.clear();
		  lastName.clear();
		  mobileNumber.clear();
		  email.clear();
		  password.clear();
		  confirmPassword.clear();
	  }

}
