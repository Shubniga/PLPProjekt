package SignupPagePF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import SignupPagePF.SignUpPageClass;

public class Verify
{
	static String er1="The First name field is required.";
	static String er2="The Last Name field is required.";
	static String er3="The Email field is required.";
	static String er4="The Email field must contain a valid email address.";
	static String er5="The Password field is required.";
	static String er6="";
	static String er7="Password not matching with confirm password.";
	
	
	//*[@id="headersignupform"]/div[2]/div/p[1]   //*[@id="headersignupform"]/div[2]/div/p[2]   //*[@id="headersignupform"]/div[2]/div/p[3]   //*[@id="headersignupform"]/div[2]/div/p[4]     //*[@id="headersignupform"]/div[2]/div/p[5]
			
	static WebDriver driver;
	SignUpPageClass SignUpPageClassObject;
	@BeforeClass
	public void beforeClass() throws InterruptedException 
	{	
		//1.	Launching the application browser, Chrome
				System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
				driver = new ChromeDriver();

				//2.	Open the web page �Registration Form.html � in the browser.
				driver.get("http://www.phptravels.net/register");
				SignUpPageClassObject = PageFactory.initElements(driver, SignUpPageClass.class);
				Thread.sleep(1000);

	}
	
	
	@Test(priority=1)
	  public void verifyFNEmptyTest() throws InterruptedException
	  {	
		String exp="The First name field is required.";
		SignUpPageClassObject.isErrorMessageFNEmpty(exp);
	  }
	
	/*@Test(priority=2)
	  public void verifyFNNumbersTest() throws InterruptedException
	  {	
		String exp="First Name should only contain Alphabets";
		SignUpPageClassObject.isErrorMessageFNNumbers(exp);
	  }*/
	@Test(priority=2)
	  public void verifyLNEmptyTest() throws InterruptedException
	  {	
		SignUpPageClassObject.isErrorMessageLNEmpty(er2);
	  }
	/*@Test(priority=1)
	  public void verifyMNEmptyTest() throws InterruptedException
	  {	
		SignUpPageClassObject.isErrorMessageMNEmpty(er3);
	  }*/
	@Test(priority=3)
	  public void verifyEmailEmptyTest() throws InterruptedException
	  {	
		SignUpPageClassObject.isErrorMessageEmailEmpty(er3);
	  }
	@Test(priority=4)
	  public void verifypassEmptyTest() throws InterruptedException
	  {	
		SignUpPageClassObject.isErrorMessagePasswordEmpty(er4);
	  }
	@Test(priority=5)
	  public void verifycompassEmptyTest() throws InterruptedException
	  {	
		SignUpPageClassObject.isErrorMessageConfirmPasswordEmpty(er5);
	  }
	
	
 
}
