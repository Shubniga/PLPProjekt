package LoginPagePF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class LoginLinkClass
{
	WebDriver driver;
	
	public LoginLinkClass(WebDriver driver)
	{
		this.driver=driver;
	}
	
	//Login heading of the page
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[1]")
	@CacheLookup // to store the element in cache memory
	WebElement heading;
	
	//email label element
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[5]/div/div[1]/label")
	@CacheLookup // to store the element in cache memory
	WebElement Emaillabel;
	
	//email input element
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[5]/div/div[1]/input")
	@CacheLookup // to store the element in cache memory
	WebElement Email;
	
	//password label element
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[5]/div/div[2]/label")
	@CacheLookup // to store the element in cache memory
	WebElement passwordlabel;
	
	//password input element
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[5]/div/div[2]/input")
	@CacheLookup // to store the element in cache memory
	WebElement password;
	
	//remember me input element
	@FindBy(xpath="//*[@id='remember-me']")
	@CacheLookup // to store the element in cache memory
	WebElement rememberme;
	
	//remember me label element
	@FindBy(xpath="//*[@id='loginfrm']/div[1]/div[5]/div/label/span/span")
	@CacheLookup // to store the element in cache memory
	WebElement remembermelabel;
	
	//login button element
	@FindBy(xpath="//*[@id='loginfrm']/button")
	@CacheLookup // to store the element in cache memory
	WebElement loginbutton;
	
	//Sign up button element
	@FindBy(xpath="//*[@id='loginfrm']/div[2]/div[1]/a")
	@CacheLookup // to store the element in cache memory
	WebElement SignUpbutton;
	
	//Forgot password element
	@FindBy(xpath="//*[@id='loginfrm']/div[2]/div[3]/a")
	@CacheLookup // to store the element in cache memory
	WebElement forgetpassword;
	
	
	//To verify Title of Login page is located
	public void verifyTitle(String expectedText)
	{
		String actualText = driver.getTitle();
		System.out.println("Actual text is :"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Login Title Verification - Passed");
		}
		else
		{
			System.out.println("Login Title Verification - Failed");
			driver.quit();
		}
	}

	//To verify Login Heading is located
	public void verifyLoginHeading(String expectedText)
	{
		String actualText = heading.getText();
		System.out.println("heading is :"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Login Heading Verification - Passed");
		}
		else
		{
			System.out.println("Login Heading Verification - Failed");
		}
	}
	
	//To verify Email label is located
	public void verifyEmailLabel(String expectedText)
	{
		String actualText = Emaillabel.getText();
		System.out.println("Email is :"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Email Label Text Verification - Passed");
		}
		else
		{
			System.out.println("Email Label Text Verification - Failed");
		}
	}
	
	//To verify Password label is located
	public void verifyPasswordLabel(String expectedText)
	{
		String actualText = passwordlabel.getText();
		System.out.println("Password is:"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Password Label Text Verification - Passed");
		}
		else
		{
			System.out.println("Password Label Text Verification - Failed");
		}
	}
	
	//To verify Remember me Label is located
	public void verifyRemembermeLabel(String expectedText)
	{
		String actualText = remembermelabel.getText();
		System.out.println("Remember me is :"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Remember me Label Text Verification - Passed");
		}
		else
		{
			System.out.println("Remember me Label Text Verification - Failed");
		}
	}
	
	//To verify Login Button text is located
	public void verifyLoginButtonText(String expectedText)
	{
		String actualText =loginbutton.getText();
		System.out.println("login button is :"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Login button Text Verification - Passed");
		}
		else
		{
			System.out.println("Login button Text Verification - Failed");
		}
	}
	
	//To verify Sign Up Button text is located
	public void verifySignUpButtonText(String expectedText)
	{
		String actualText =SignUpbutton.getText();
		System.out.println("Signup button is :"+actualText);
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Sign Up Button text Verification - Passed");
		}
		else
		{
			System.out.println("Sign Up Button text Verification - Failed");
		}
	}
	
	//To verify Forget Password Button text is located
		public void verifyForgotPasswordText(String expectedText)
		{
			String actualText =forgetpassword.getText();
			System.out.println("Forget Password is :"+actualText);
			if(stringEquals(actualText,expectedText))
			{
				System.out.println("Forget Password Button text Verification - Passed");
			}
			else
			{
				System.out.println("Forget Password Button text Verification - Failed");
			}
		}
		
		//To Verify email input field is displayed & enabled
		public boolean isEmailDisplayed()
		{
			if(Email.isDisplayed()&&Email.isEnabled())
			{
				return true;
			}
			else
				return false;
		}
		
		//To Verify password input field is displayed & enabled
		public boolean isPasswordDisplayed()
		{
			if(password.isDisplayed()&&password.isEnabled())
			{
				return true;
			}
			else
				return false;
		}
		
		//To Verify Remember me input field is displayed & enabled
		public boolean isRememberMeDisplayed()
		{
			if(rememberme.isDisplayed()&&rememberme.isEnabled())
			{
				return true;
			}
			else
				return false;
		}

		//To Verify Login Button input field is displayed & enabled
		public boolean isLoginButtonDisplayed()
		{
			if(loginbutton.isDisplayed()&&loginbutton.isEnabled())
			{
				return true;
			}
			else
				return false;
		}

		//To Verify Remember me input field is displayed & enabled
		public boolean isSignUpButtonDisplayed()
		{
			if(SignUpbutton.isDisplayed()&&SignUpbutton.isEnabled())
			{
				return true;
			}
			else
				return false;
		}

		//To Verify Login Button input field is displayed & enabled
		public boolean isForgotPasswordButtonDisplayed()
		{
			if(forgetpassword.isDisplayed()&&forgetpassword.isEnabled())
			{
				return true;
			}
			else
				return false;
		}		

		private boolean stringEquals(String actualText, String expectedText) 
		{
			if(expectedText.contentEquals(actualText))
				return true;
			else
				return false;
		}
}