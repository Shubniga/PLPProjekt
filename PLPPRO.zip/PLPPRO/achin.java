package kk;

import java.util.ArrayList;
import java.util.Arraylist;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhpTravelsValidations {
	
public static boolean stringStartsWith1(String string,String startswith,int offset){
if(String.startsWith(startswith,offset))return true;
else return false;
}
public static boolean stringEndsWith(String string,String endswith){
if(String.endsWith(endswith))return true;
else return false;
}

public static boolean stringContains(String string,String contains){
if(String.contains(contains))return true;
else return false;
}

public static boolean stringEqualswith(String string,String with){
if(String.equals(with))return true;
else return false;
}
public static boolean isAlphanumeric(String string){
	
String regex="[A-Za-z0-9]{0,}";
if(Pattern.matches(regex, string)){
	System.out.println("Alphanumeric String");
	return true;
}
else{ 
	System.out.println("Not Alphanumeric string");
	return false;
}
}

public static boolean isAlphabetesOnly(String string){
	// string contains uppercase character
public static boolean containsUpperCaseChar(String string){
		// string contains special character excluding blank space
	public static boolean containsSpecialChar(String string){
			// string contains a specific value
public static boolean listContains(List list ,Object obj){
				// index of a specific value in the list
	//compare two list <list<String>> and find out the 
	//cells contains different values 
	
	public static void main(string[]args){
		string s ="my name is Achin";//  \\s not allow spaces and \\ allow spaces	
		System.out.println(stringStartsWith(s,"my",0));
		System.out.println(stringEndsWith(s,"@chin",0));
		System.out.println(stringContains(s,"is"));
		System.out.println(stringEqualsWith(s,s));
		isAlphanumeric(s);
		isAlphabetsOnly(s);
		containsUpperCaseChar(s);
		containsSpecialChar(s);
		ArrayList<String> list = new ArrayList<>();
		list.add(12);
		list.add(28);
		System.out.println(listContains(list,"Achin"));
		System.out.println(listContains(list1,"13"));
		
		
		System.out.println((int)('a')+" "+(int)('z'));	
		System.out.println((int)('A')+" "+(int)('Z'));
		System.out.println((int)('0')+" "+(int)('9'));
	}
}

