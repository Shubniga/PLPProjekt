package MYACCOUNT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class SinUPLinkClass
{
	WebDriver driver;

	public SinUPLinkClass(WebDriver driver)
	{
		this.driver =driver;
	}


	//My Account Drop Down locator
	@FindBy(xpath="//*[@id='li_myaccount']/a")
	@CacheLookup // to store the element in cache memory
	WebElement myAccount;

	//Login Link Locator
	@FindBy(how=How.XPATH, using="//*[@id='li_myaccount']/ul/li[1]/a")
	@CacheLookup
	WebElement loginlink;

	//Sign UP Link Locator
	@FindBy(how=How.XPATH, using="//*[@id='li_myaccount']/ul/li[2]/a")
	@CacheLookup
	WebElement signUPlink;

	//Select My Account Options
	public void selectMyAccountLink(int option)
	{
		Select sel=new Select(myAccount);
		sel.selectByIndex(option);
	}


	//Verify My Account Drop down is displayed
	public boolean isMyAccountDropdowndDisplayed()
	{
		if(myAccount.isDisplayed()&&myAccount.isEnabled())
		{
			System.out.println("My ACCOUNT Drop Down is displayed and enabled");
			return true;
		}
		else
		{
			System.out.println("My ACCOUNT Drop Down is not displayed");
			return false;
		}
	}

	//Verify Login link has meaningful text
	public boolean isLoginLinkDisplayed(String expectedText)
	{
		String actualText = loginlink.getText();
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Login option in My account Dropdown is present");
			return true;
		}
		else
		{
			System.out.println("Login option in My account Dropdown is NOT present");
			return false;
		}
	}

	//Verify sign UP link has meaningful text
	public boolean isSignUPLinkDisplayed(String expectedText)
	{
		String actualText = signUPlink.getText();
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("Sign Up option in My account Dropdown is present");
			return true;
		}
		else
		{
			System.out.println("Sign Up option in My account Dropdown is NOT present");
			return false;
		}
	}

	//verify My Account link is Meaningful
	public boolean isMyAccountDDMeaningfull(String expectedText)
	{
		String actualText = myAccount.getText();
		if(stringEquals(actualText,expectedText))
		{
			System.out.println("MY ACCOUNT Dropdown has Meaning full Text");
			return true;
		}
		else
		{
			System.out.println("MY ACCOUNT Dropdown dosen't has Meaning full Text");
			return false;
		}
	}

	//verify title of page
	public void verifyTitle(String expectedTitle)
	{
		String actualTitle = driver.getTitle();
		if(stringEquals(actualTitle,expectedTitle))
		{
			System.out.println("Title Verification - Passed");
		}
		else
		{
			System.out.println("Title Verification - Failed");
			driver.quit();
		}

	}

	//Checks if two strings are equal
	public boolean stringEquals(String actualText, String expectedText)
	{
		if(expectedText.contentEquals(actualText))
			return true;
		else
			return false;
	}

	// Verify that login option in MY ACCOUNT Drop down is navigating to Login page
	public boolean verifyLoginLink(String expectedTitle)
	{
		selectMyAccountLink(0);
		String actualTitle = driver.getTitle();
		if(stringEquals(actualTitle, expectedTitle))
		{
			System.out.println("Login option is navigating to login page");
			return true;
		}
		else
		{
			System.out.println("Login option  is NOT navigating to login page");
			return false;
		}
	}

	// Verify that Sign Up option in MY ACCOUNT Drop down is navigating to Sign Up page
	public boolean verifySignUpLink(String expectedTitle)
	{
		selectMyAccountLink(1);
		String actualTitle = driver.getTitle();
		if(stringEquals(actualTitle, expectedTitle))
		{
			System.out.println("Sign Up option is navigating to Sign Up page");
			return true;
		}
		else
		{
			System.out.println("Sign Up option  is NOT navigating to Sign Up page");
			return false;
		}
	}


}
