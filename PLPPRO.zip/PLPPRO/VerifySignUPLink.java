package MYACCOUNT;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import MYACCOUNT.SinUPLinkClass;

public class VerifySignUPLink
{
	static WebDriver driver;
	SinUPLinkClass SignUPLinkClassObject;
	@BeforeClass
	public void beforeClass()
	{	
		//1.	Launching the application browser, Chrome
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();

		//2.	Open the web page �Registration Form.html � in the browser.
		driver.get("http://www.phptravels.net/");
		SignUPLinkClassObject = PageFactory.initElements(driver, SinUPLinkClass.class);


	}

	//3.	Verify the title �PHPTRAVELS | Travel Technology Partner� of the page. 
	//The test should stop execution if the title of the page is not matching with the expected title.
	@Test(priority=1)
	public void verifyTitleTest()
	{	
		String expectedTitle="PHPTRAVELS | Travel Technology Partner";
		SignUPLinkClassObject.verifyTitle(expectedTitle);
	}

	//4. Verify Meaning full text is present in MY ACCOUNT drop down
	@Test(priority=2)
	public void verifySignupDDTextTest()
	{	
		String expectedText="MY ACCOUNT";
		SignUPLinkClassObject.isMyAccountDDMeaningfull(expectedText);
	}

	//5. Verify Meaningful text(Login) is present in Login option of MY ACCOUNT drop down option
	@Test(priority=3)
	public void verifyLoginLinkTextTest()
	{	
		String expectedText="Login";
		SignUPLinkClassObject.isLoginLinkDisplayed(expectedText);
	}

	//6. Verify Meaningful text(Sign Up) is present in Sign Up option of MY ACCOUNT drop down option
	@Test(priority=4)
	public void verifySignUpLinkTextTest()
	{	
		String expectedText="Sign Up";
		SignUPLinkClassObject.isSignUPLinkDisplayed(expectedText);
	}

	//7. Verify that login option in MY ACCOUNT Drop down is navigating to Login page
	@Test(priority=5)
	public void verifyLoginLinkTest()
	{	
		String expectedText="Login";
		SignUPLinkClassObject.verifyLoginLink(expectedText);
	}

	//8. Verify that Sign Up option in MY ACCOUNT Drop down is navigating to Sign Up page
	@Test(priority=6)
	public void verifySignUpLinkTest()
	{	
		String expectedText="Sign Up";
		SignUPLinkClassObject.verifySignUpLink(expectedText);
	}


}
