package LoginPagePF;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import LoginPagePF.LoginLinkClass;

public class VerifyLoginLinkClass {
	static WebDriver driver;
	LoginLinkClass LoginLinkClassObject;
	
	@BeforeClass
	public void beforeClass() throws InterruptedException
	{	
		//1.	Launching the application browser, Chrome
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();

		//2.	Open the web page �Registration Form.html � in the browser.
		driver.get("http://www.phptravels.net/Login/");
		LoginLinkClassObject = PageFactory.initElements(driver, LoginLinkClass.class);
		Thread.sleep(5000);
	}

	//3.	Verify the title �Login� of the page. 
	//The test should stop execution if the title of the page is not matching with the expected title.
	@Test(priority=1)
	public void verifyTitle()
	{	
		String expectedTitle="Login";
		LoginLinkClassObject.verifyTitle(expectedTitle);
	}
	
	@Test(priority=2)
	public void verifyLoginHeading()
	{	
		String expectedTitle="LOGIN";
		LoginLinkClassObject.verifyLoginHeading(expectedTitle);
	}
	
	@Test(priority=3)
	public void verifyEmailLabel()
	{	
		String expectedTitle="Email";
		LoginLinkClassObject.verifyEmailLabel(expectedTitle);
	}

	@Test(priority=4)
	public void verifyPasswordLabel()
	{	
		String expectedTitle="Password";
		LoginLinkClassObject.verifyPasswordLabel(expectedTitle);
	}
	
	@Test(priority=5)
	public void verifyRemembermeLabel()
	{	
		String expectedTitle="  Remember Me  ";
		LoginLinkClassObject.verifyRemembermeLabel(expectedTitle);
	}
	
	@Test(priority=6)
	public void verifyLoginButtonText()
	{	
		String expectedTitle="LOGIN";
		LoginLinkClassObject.verifyLoginButtonText(expectedTitle);
	}
	
	@Test(priority=7)
	public void verifySignUpButtonText()
	{	
		String expectedTitle="SIGN UP";
		LoginLinkClassObject.verifySignUpButtonText(expectedTitle);
	}
	
	@Test(priority=8)
	public void verifyForgetPasswordText()
	{	
		String expectedTitle="FORGET PASSWORD";
		LoginLinkClassObject.verifyForgotPasswordText(expectedTitle);
	}
}
